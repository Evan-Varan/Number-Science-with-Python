### Evan Varan
### lze4
### 41
### Final Project - Option 1

def dec2bin(x, n=1):
    """
    Converts a signed decimal number to a signed binary number with a specified number of bits.

    Parameters:
        x (int): The decimal number to convert.
        n = 1 (int): The number of bits to use in the binary number (default one).

    Returns:
        str: The converted decimal number as a binary string.
    """
    if type(x) != int:
        return "Please enter an integer"
    binString = ""
    originalNumber = x
    number = abs(x)
    while number > 0:
        mod = number % 2
        binString = str(mod) + binString
        number = number // 2

    while len(binString) < n:
        binString = "0" + binString

    if originalNumber < 0:
        binString = twosComplement(binString, "Binary")

    return binString
def twosComplement(binString, returnType):
    """
    Helper method to complete twos complement. Flips all bits in a binary
    string and adds one(int) to the binary string.

    Parameters:
        binString (str): The binary string to complete twos complement on.
        returnType (str): The type we want to return (decimal number or binary number).

    Returns:
        twosComplementBinary(int or str): The twos complement of the binary string as either a decimal number (int) or a binary string (str)

    """
    invertedString = ""
    for i in range(len(binString)):
        if binString[i] == '0':
            invertedString += '1'
        elif binString[i] == '1':
            invertedString += '0'

    twosComplementDecimal = 0
    exp = 0

    for i in range(len(invertedString) - 1, -1, -1):
        if invertedString[i] == '1':
            twosComplementDecimal += 2 ** exp
        exp += 1
    twosComplementDecimal += 1

    if returnType == "Decimal":
        return twosComplementDecimal
    elif returnType == "Binary":
        binString = ""
        while twosComplementDecimal > 0:
            mod = twosComplementDecimal % 2
            binString = str(mod) + binString
            twosComplementDecimal = twosComplementDecimal // 2
        return binString
def bin2dec(x):
    """
    Converts a signed binary number to a signed decimal number.

    Parameters:
        x (str): The signed binary number to convert.

    Returns:
        int: The converted binary number as a decimal integer.
    """
    if not isinstance(x, str) or not set(x).issubset({'0', '1'}):
        return "Please enter a binary number"
    decimalNumber = 0
    exp = 0
    if x[0] == '0':
        for i in range (len(x) - 1, -1, -1):
            if x[i] == '1':
                decimalNumber += 2 ** exp
            exp +=1
        return decimalNumber
    else:
        decimalNumber = twosComplement(x, "Decimal")
        return decimalNumber * -1
def dec2hex(x, n=1):
    """
    Converts a signed decimal number to a signed hex number.

    Parameters:
        x (int): The signed decimal number to convert.
        n=1 (int): The number of hex digits to display.

    Returns:
        str: The converted decimal number as a hex number.
    """
    if type(x) != int:
        return "Please enter an integer"
    hexString = ""
    if x < 0:
        if n > 1:
            binaryNumber = dec2bin(x, n * 4)
            while len(binaryNumber) % 4 != 0:
                binaryNumber = "0" + binaryNumber
        else:
            binaryNumber = dec2bin(x, n)
            while len(binaryNumber) % 4 != 0:
                binaryNumber = "0" + binaryNumber
            binaryNumber = twosComplement(binaryNumber, "Binary")

        for i in range(0, len(binaryNumber), 4):
            fourBitChunk = binaryNumber[i:i + 4]
            if fourBitChunk[0] == "1":
                fourBitChunk = "0" + fourBitChunk
            value = bin2dec(fourBitChunk)
            if value == 10:
                addString = "A"
            elif value == 11:
                addString = "B"
            elif value == 12:
                addString = "C"
            elif value == 13:
                addString = "D"
            elif value == 14:
                addString = "E"
            elif value == 15:
                addString = "F"
            else:
                addString = str(value)
            hexString += addString
        return hexString


    else:
        while x > 0:
            mod = x % 16
            if mod == 10:
                addString = "A"
            elif mod == 11:
                addString = "B"
            elif mod == 12:
                addString = "C"
            elif mod == 13:
                addString = "D"
            elif mod == 14:
                addString = "E"
            elif mod == 15:
                addString = "F"
            else:
                addString = str(mod)
            hexString = addString + hexString
            x = x // 16
        while len(hexString) < n:
            hexString = "0" + hexString
        return hexString
def hex2dec(x):
    """
    Converts a signed hex number to a decimal number.

    Parameters:
        x (str): The signed hex number to convert.

    Returns:
        int: The converted hex number as a decimal number.
    """
    if type(x) != str or not set(x).issubset(
            {'A', 'B', 'C', 'D', 'E', 'F', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'}):
        return "Please enter a hexadecimal number"
    returnNumber = 0

    for i in range(len(x) - 1, -1, -1):
        str_value = x[i]
        if str_value == "A":
            addNum = 10
        elif str_value == "B":
            addNum = 11
        elif str_value == "C":
            addNum = 12
        elif str_value == "D":
            addNum = 13
        elif str_value == "E":
            addNum = 14
        elif str_value == "F":
            addNum = 15
        else:
            addNum = int(str_value)
        returnNumber = returnNumber + (addNum * (16 ** (len(x) - 1 - i)))
    if x[0] == "F":
        returnNumber = -1 * ((2 ** (
                    len(x) * 4)) - returnNumber)  # Finds the positive magnitude to avoid having to convert to binary
    return returnNumber
def bin2hex(x):
    """
    Converts a signed binary number to a hex number.

    Parameters:
        x (str): The signed binary number to convert.

    Returns:
        str: The converted binary number as a hex number.
    """
    if type(x) != str or not set(x).issubset({'0', '1'}):
        return "Please enter a binary number"
    hexString = ""
    for i in range(0, len(x), 4):
        fourBitChunk = x[i:i+4]
        if fourBitChunk[0] == "1":
            fourBitChunk = "0" + fourBitChunk
        value = bin2dec(fourBitChunk)
        if value == 10:
            addString = "A"
        elif value == 11:
            addString = "B"
        elif value == 12:
            addString = "C"
        elif value == 13:
            addString = "D"
        elif value == 14:
            addString = "E"
        elif value == 15:
            addString = "F"
        else:
            addString = str(value)
        hexString += addString
    return hexString
def hex2bin(x):
    """
    Converts a signed hex number to a signed binary number.

    Parameters:
        x (str): The signed hex number to convert.

    Returns:
        str: The converted hex number as a signed binary number.
    """

    if type(x) != str or not set(x).issubset({'A', 'B','C', 'D','E', 'F','1', '2','3', '4','5', '6','7', '8','9', '0'}): #TODO: verify this works
        return "Please enter a hexadecimal number"
    binString = ""
    for i in range(len(x)):
        decValue = x[i]
        if decValue == "A":
            decValue = "10"
        elif decValue == "B":
            decValue = "11"
        elif decValue == "C":
            decValue = "12"
        elif decValue == "D":
            decValue = "13"
        elif decValue == "E":
            decValue = "14"
        elif decValue == "F":
            decValue = "15"
        binValue = dec2bin(int(decValue), 4)
        binString += binValue
    return binString
def dec2float(x):
    """
    Converts a signed decimal number to a signed 32bit float number in IEEE 754 single-precision.

    Parameters:
        x (float): The signed decimal number to convert.

    Returns:
        str: The converted decimal number as a signed 32bit float number in IEEE 754 single-precision.
    """
    if type(x) != int and type(x) != float:
        return "Please enter a number"

    if x == 0:  # incase 0 is input return 32 0's
        return '0' * 32
    elif x >= 0:
        sign_bit = "0"
    else:
        sign_bit = "1"

    if isinstance(x, int):  # whole numbers
        x = abs(x)
        binary_value = dec2bin(x)
        exponent = len(binary_value[1:]) + 127
        exponent = str(dec2bin(exponent, 8))
        mantissa = str(binary_value[1:])

        while len(mantissa) <= 23:
            mantissa = mantissa + "0"
        while len(mantissa) > 23:
            mantissa = mantissa[:-1]
        float_value = sign_bit + exponent + mantissa
        return float_value

    if isinstance(x, float):  # floats
        x = abs(x)
        int_string = str(dec2bin(int(abs(x))))
        if "." in str(x):
            decimal_places = len(str(x).split('.')[1])
            fraction_part = round(abs(int(x) - x), decimal_places)
        else:
            decimal_places = int(str(x)[-2:])
            fraction_part = x
        fraction_string = ""

        exponent = 0
        if x < 1:  # for really small numbers with no integer component
            while x < 1:
                x *= 2
                exponent -= 1

            fractional_part = x - 1
            exponent = dec2bin(exponent + 127, 8)  # only need 8 bits for exponent

            # only need 23 bits for mantissa
            mantissa = ""
            for i in range(23):
                fractional_part *= 2
                int_part = int(fractional_part)
                mantissa += str(int_part)
                fractional_part -= int_part

        else:
            while fraction_part > 0 and len(
                    fraction_string) < 8:  # 8 slots open for the exponent in case of repeating float
                fraction_part = round(2 * fraction_part, decimal_places)

                if fraction_part >= 1:
                    fraction_string += "1"
                    fraction_part -= 1
                else:
                    fraction_string += "0"

            integer_and_binary = int_string + fraction_string
            exponent = dec2bin(len(int_string) - 1 + 127)
            mantissa = integer_and_binary[1:]

            while len(mantissa) <= 23:
                mantissa = mantissa + "0"
            while len(mantissa) > 23:
                mantissa = mantissa[:-1]

        return sign_bit + exponent + mantissa
def bin2float(x):
    """
    Converts a signed binary number to a signed 32bit float number in IEEE 754 single-precision.

    Parameters:
        x (str): The signed binary number to convert.

    Returns:
        int: The converted binary number as a signed 32bit float number in IEEE 754 single-precision.
    """
    if type(x) != str or not set(x).issubset({'0', '1'}):
        return "Please enter a binary number"
    decimal_number = bin2dec(x)
    float_number = dec2float(decimal_number)
    return float_number
def float2dec(x):
    """
    Converts a signed 32bit float in IEEE 754 single-precision number to a signed decimal number.

    Parameters:
        x (str): The signed 32bit float in IEEE 754 single-precision number.

    Returns:
        int: The converted decimal number from a signed 32bit float number in IEEE 754 single-precision.
    """
    if type(x) != str or not set(x).issubset({'0', '1'}):
        return "Please enter a binary number"
    x = str(x)
    sign_bit = x[0]
    exponent_bits = x[1:9]
    mantissa_bits = x[9:]
    if sign_bit == "1":
        sign_bit = -1
    else:
        sign_bit = 1
    exponent = bin2dec("0" + exponent_bits) - 127
    mantissa_decimal = bin2dec("01" + mantissa_bits) / (2**23)
    decimal_number = sign_bit * (2 ** exponent) * mantissa_decimal
    return decimal_number


#Testing
def try_cases(file_name, check_int, function):
    """
        For each line in the test_cases.txt file, tests all cases in the line for a specified function.
        Prints the input and output of each test cases using the specified function.

        Parameters:
            file_name (file): The file holing test vectors.
            check_int (bool): True if input is decimal, False otherwise.
            function (function): the function to test.

        Returns:
            int: The converted decimal number from a signed 32bit float number in IEEE 754 single-precision.
        """
    first_line = file_name.readline().strip()
    name_of_function, vector = first_line.split("=",1)
    vector_cases = eval(vector.strip()) #convert line to a list type
    print(f"{function.__name__} Testing:")
    print(f"Cases: {vector_cases}")
    for case in vector_cases:
        if check_int:
            if not isinstance(case,tuple): #if there is only 1 parameter given wrap it as a new tuple with a single element
                case = (case,)
            int_case_list = []
            for x in case: #this loop is to make sure each element is parsed and sent to function correctly
                try: #try converting values for case into ints as for example dec2bin takes integers
                    int_case_list.append(int(x))
                    is_int = True
                except ValueError:
                    is_int = False
                    break
            if is_int:
                if len(int_case_list) > 1:
                    int_case = tuple(int_case_list)
                    output = function(*int_case) # "*" is used to pass each element in tuple as a seperate parameter to function
                    print(f"Input: {int_case} Output: {output}")
                else:
                    print(f"Input: {int_case_list[0]} Output: {function(int_case_list[0])}")
            else:
                output = dec2bin(case)
                print(f"Input: {case} Output: {output}")
        else:
            print(f"Input: {case} Output: {function(case)}")


with open("test_cases.txt", "r") as file:
    try_cases(file, True, dec2bin)
    print("\n")
    try_cases(file, False, bin2dec)
    print("\n")
    try_cases(file, True, dec2hex)
    print("\n")
    try_cases(file, False, hex2dec)
    print("\n")
    try_cases(file, False, bin2hex)
    print("\n")
    try_cases(file, False, hex2bin)
    print("\n")
    try_cases(file, False, dec2float)
    print("\n")
    try_cases(file, False, bin2float)
    print("\n")
    try_cases(file, False, float2dec)
file.close()